# Accueil - Gestion d'Agendas Partagés (GAP) v3.0.0

## Accueil

 **Brief description of this Implementation Guide**
 The purpose of this implementation guide is to allow the management of resources (people, places or objects), the management of the availability of these resources, the consultation and synchronization of calendars and the making of appointments. 

>  **Attention !** Cette version de l'Implementation Guide est en intégration continue et est soumise à des changements réguliers. La version officielle est accessible à l'adresse https://interop.esante.gouv.fr/ig/fhir/gap 

Ce guide d'implémentation a pour objet de permettre la gestion de ressources (personnes, lieux ou objets), la gestion des disponibilités de ces ressources, la consultation et la synchronisation d’agenda et la prise de rendez-vous.

### Scénarios d'implémentation

Les présentes spécifications techniques définissent des flux pouvant s’appliquer à deux scénarios d’implémentation :

* **Gestion centralisée d’agendas**

Le système gestionnaire d’agenda gère les disponibilités et les rendez-vous des ressources de manière centralisée. Les systèmes initiateurs sollicitent ponctuellement le gestionnaire d’agenda en lui envoyant des déclarations de nouvelles disponibilités des ressources, des requêtes de recherche de disponibilités de ressources ou des demandes de rendez-vous.

* **Gestion déléguée d’agendas**

Dans ce scénario le système initiateur peut gérer, par délégation du gestionnaire d’agendas, les disponibilités des ressources et la prise de rendez-vous. Des échanges fréquents de synchronisation des disponibilités et des rendez-vous entre ces acteurs doivent donc être optimisés notamment en termes de volumétrie.

### Profils définis dans le guide d'implémentation

| | |
| :--- | :--- |
| Titre du profil | Description |
| [GAP-BundleResultatReponseADemandeConsultationDisponibilites](StructureDefinition-gap-bundle-reponse-demande-consult-dispo.md) | Profil du bundle de réponse à la demande de consultation des disponibilités d’une ou de plusieurs ressources. Sur la durée demandée, elle devra contenir les informations sur le temps libre ou occupé de chacune des ressources. La réponse contient donc les disponibilités (Slot) des ressources répondant aux critères de recherche de la demande. Les Slot portant le statut free représentent les disponibilités (status=free). Status=busy pour les indisponibilités correspondant à des rendez-vous pris |
| [GAP-BundleResultatReponseADemandeConsultationRDV](StructureDefinition-gap-bundle-reponse-demande-consult-rdv.md) | Profil du bundle de réponse à la recherche de rendez-vous dans l’agenda d’une ressource. Sur la durée demandée, il devra contenir les informations sur les rendez-vous répondant aux critères de recherche envoyés dans la demande |
| [GAP-FrAppointment](StructureDefinition-gap-fr-appointment.md) | Profil décrivant un rendez-vous médical |
| [GAP-FrSchedule](StructureDefinition-gap-fr-schedule.md) | Profil décrivant un agenda médical |
| [GAP-FrSlot](StructureDefinition-gap-fr-slot.md) | Profil décrivant un créneau |

D'autres ressources mentionnés dans ce document n'ont pas été profilées (liste non exhaustive).

| | | | |
| :--- | :--- | :--- | :--- |
| Patient | FrPatient | hl7.fhir.fr.core | Ce profil spécifie les identifiants de patient utilisés en France. Il utilise des extensions internationales (birthplace et nationalité) et ajoute des extensions propres à la France. |
| Practitioner | AsPractitionerProfile | ans.fhir.fr.annuaire | Profil du praticien français. |
| PractitionerRole | AsPractitionerRoleProfile | ans.fhir.fr.annuaire | Profil de la situation d'exercice du praticien français. |
| Organization | AsOrganizationProfile | ans.fhir.fr.annuaire | Ce profil spécifie les types d'identifiants pour l'organisation en France, et ajoute des extensions françaises. |
| Location | FrLocation | hl7.fhir.fr.core | Ce profil spécifie les rôles joués par un lieu en France. |
| HealthcareService | FrHealthcareService | hl7.fhir.fr.core | Ce profil spécifie les services en France. |
| RelatedPerson | FrRelatedPerson | hl7.fhir.fr.core | Ce profil spécifie les personnes reliées à un patient. |

Dans l’ensemble de cet IG, lorsqu’il est fait référence à ces ressources, les profils associés doivent être utilisés.


### Dépendances







### A propos

Ce document s’adresse aux développeurs des interfaces interopérables des systèmes implémentant le volet « Gestion d’agendas partagés » ou à toute autre personne intervenant dans le processus de mise en place de ces interfaces.

Cette spécification technique s’appuie sur le standard HL7 FHIR et son API REST. L’hypothèse est faite que le lecteur est familier de ces concepts.

Les spécifications techniques présentées dans ce volet ne présagent pas des conditions de leur mise en œuvre dans le cadre d’un système d’information partagé. Il appartient à tout responsable de traitement de s’assurer que les services utilisant ces spécifications respectent les cadres et bonnes pratiques applicables à ce genre de service (ex. cadre juridique, ergonomie, accessibilité…).

Il est à noter que les contraintes de sécurité concernant les flux échangés ne sont pas traitées dans ce document. Celles-ci sont du ressort de chaque responsable de l’implémentation du mécanisme qui est dans l’obligation de se conformer au cadre juridique en la matière. L’ANS propose des référentiels dédiés à la politique de sécurité (la [PGSSI-S](http://esante.gouv.fr/services/politique-generale-de-securite-des-systemes-d-information-de-sante-pgssi-s/en-savoir-plus-0)) et des mécanismes de sécurisation sont définis dans les volets de la [couche Transport](http://esante.gouv.fr/services/referentiels/ci-sis/espace-publication/couche-transport) du Cadre d’Interopérabilité des systèmes d’information de santé (CI-SIS).

